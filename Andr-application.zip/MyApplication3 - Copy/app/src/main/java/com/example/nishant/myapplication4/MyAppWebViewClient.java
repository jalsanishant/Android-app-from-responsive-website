package com.example.nishant.myapplication4;

import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;




public class MyAppWebViewClient extends WebViewClient {

    @Override
    public boolean shouldoverrideUrlLoading(WebView view, String url) {
        if (Uri.parse(url).getHost().endsWith("https://sample-app-jalsanishant.c9.io")) {
            return false;
        }

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        view.getContext().startActivity(intent);
        return true;
    }

}
